import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:stem_hub/core/app_constants.dart';

class CustomDrawer extends StatelessWidget {
  const CustomDrawer({Key? key, required this.showBG}) : super(key: key);
  final bool showBG;

  @override
  Widget build(BuildContext context) {
    return Drawer(
        child: ListView(
      children: [
        DrawerHeader(
            padding: CustomPadding.zero,
            margin: CustomPadding.zero,
            decoration: const BoxDecoration(color: CustomColors.primary),
            child: showBG
                ? Positioned.fill(
                    child: Image.asset(
                      'assets/images/z_flag.jpg',
                      fit: BoxFit.cover,
                    ),
                  )
                : Center(
                    child: Text(
                    'STEM Hub',
                    style: TextStyle(
                        color: CustomColors.shade.withOpacity(0.4),
                        fontSize: 24),
                  ))),
        ListTile(
          leading: const Icon(Icons.home_outlined),
          title: const Text('scholarships'),
          onTap: () {/* Update the state of the app.*/},
        ),
        ListTile(
          leading: const Icon(Icons.book_outlined),
          title: const Text('summer school'),
          onTap: () {
            // Update the state of the app.
          },
        ),
        ListTile(
          leading: const Icon(Icons.pentagon_outlined),
          title: const Text('fellowships'),
          onTap: () {
            // Update the state of the app.
          },
        ),
        ListTile(
          leading: const Icon(Icons.exit_to_app_rounded),
          title: const Text('Competitions'),
          onTap: () {
            Navigator.pop(context);
          },
        ),
        ListTile(
          leading: const Icon(Icons.close),
          title: const Text('internships'),
          onTap: () {
            SystemNavigator.pop();
          },
        ),
      ],
    ));
  }
}
