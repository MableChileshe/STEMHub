import 'package:flutter/material.dart';

enum Funding { fullyFunded, semiFunded, noFunding }

class HomeCard {
  String title;
  Enum funding;
  String deadline;
  String image;

  HomeCard(
      {required this.title,
      required this.funding,
      required this.deadline,
      required this.image});
}
