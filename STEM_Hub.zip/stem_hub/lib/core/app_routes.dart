import 'package:flutter/material.dart';
import 'package:stem_hub/screens/home_screen.dart';
import 'package:stem_hub/screens/login_screen.dart';

class AppRoutes {
  static const String home = "home";

  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    return MaterialPageRoute(builder: (context) {
      switch (settings.name) {
        case home:
          return HomeScreen(title: 'Stem HUB');
        default:
          return const LoginScreen();
      }
    });
  }
}
