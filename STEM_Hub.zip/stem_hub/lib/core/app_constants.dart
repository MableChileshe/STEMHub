import 'package:flutter/material.dart';

class CustomColors {
  static const Color primary = Color.fromARGB(255, 229, 195, 241);
  static const Color shade = Color.fromARGB(255, 184, 100, 214);
  static const Color lightGrey = Color.fromARGB(255, 240, 238, 238);
  static const Color darkGrey = Color.fromARGB(255, 84, 84, 84);
}

class CustomPadding {
  static const EdgeInsets zero = EdgeInsets.zero;
  static const EdgeInsets vertical_4 = EdgeInsets.symmetric(vertical: 4);
  static const EdgeInsets all_8 = EdgeInsets.all(8);
  static const EdgeInsets all_12 = EdgeInsets.all(12);
}

class CustomTheme {
  static ThemeData get stemTheme {
    return ThemeData(
        primaryColor: CustomColors.primary,
        scaffoldBackgroundColor: CustomColors.lightGrey,
        textTheme: ThemeData.light().textTheme,
        appBarTheme: const AppBarTheme(
            backgroundColor: CustomColors.primary,
            elevation: 0,
            titleTextStyle: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold)),
        fontFamily: 'Roboto',
        buttonTheme: ButtonThemeData(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8.0)),
            buttonColor: CustomColors.primary),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
            backgroundColor: CustomColors.primary),
        elevatedButtonTheme: ElevatedButtonThemeData(
            style: ButtonStyle(
                elevation: MaterialStateProperty.all(0),
                backgroundColor:
                    MaterialStateProperty.all(CustomColors.primary))),
        textButtonTheme: const TextButtonThemeData(),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
            backgroundColor: CustomColors.primary,
            elevation: 0,
            selectedItemColor: Colors.white,
            unselectedItemColor: CustomColors.darkGrey));
  }
}
