import 'package:flutter/material.dart';
import 'package:stem_hub/core/app_constants.dart';
import 'package:stem_hub/core/app_routes.dart';
import 'package:stem_hub/screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Stem Hub',
      theme: CustomTheme.stemTheme,
      home: HomeScreen(title: 'STEM Hub'),
      onGenerateRoute: AppRoutes.onGenerateRoute,
    );
  }
}
