import 'package:flutter/material.dart';
import 'package:stem_hub/core/app_constants.dart';
import 'package:stem_hub/custom_widgets/custom_drawer.dart';
import 'package:stem_hub/models/home_card.dart';

class HomeScreen extends StatefulWidget {
  HomeScreen({Key? key, required this.title}) : super(key: key);

  final String title;
  final List<String> top_menu = ["Scholarships", "Conferences", "Internships"];

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late SnackBar snackBar;
  int navBar_selectedItem = 0;
  late bool showDrawerBackground;

  @override
  void initState() {
    super.initState();
    showDrawerBackground = false;
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
        appBar: AppBar(
          title: Text(widget.title),
        ),
        drawer: CustomDrawer(showBG: showDrawerBackground),
        bottomNavigationBar: BottomNavigationBar(
            onTap: ((value) {
              setState(() {
                navBar_selectedItem = value;
              });
            }),
            currentIndex: navBar_selectedItem,
            items: const [
              BottomNavigationBarItem(
                  icon: Icon(Icons.menu), label: 'categories'),
              BottomNavigationBarItem(
                  icon: Icon(Icons.favorite), label: 'favorites'),
              BottomNavigationBarItem(
                  icon: Icon(Icons.badge), label: 'My Dashboard'),
            ]),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                height: 64,
                color: Colors.white,
                child: ListView.builder(
                  shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  padding: CustomPadding.all_12,
                  itemCount: widget.top_menu.length,
                  itemBuilder: ((context, index) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6.0),
                      child: ElevatedButton(
                        onPressed: () {},
                        child: Text(widget.top_menu[index]),
                      ),
                    );
                  }),
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 18.0, vertical: 8),
                color: Colors.white,
                child: const Text(
                  'Recent',
                  style: TextStyle(color: CustomColors.darkGrey),
                ),
              ),
              const SizedBox(height: 4),
              Expanded(
                child: ListView.builder(
                    itemCount: 3,
                    itemBuilder: (context, item) {
                      return GestureDetector(
                        onTap: () {
                          snackBar = SnackBar(
                            content: Text('You selected item ${item + 1}'),
                            duration: const Duration(milliseconds: 1200),
                          );
                          ScaffoldMessenger.of(context).showSnackBar(snackBar);
                        },
                        child: Container(
                            width: size.width,
                            margin: const EdgeInsets.symmetric(vertical: 4),
                            color: Colors.white,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: size.width / 2.6,
                                  height: 110,
                                  color: Colors.amber,
                                  child: Image.asset(
                                    'assets/images/thumbnail.jpg',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.all(10.0),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      mainAxisSize: MainAxisSize.max,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.stretch,
                                      children: [
                                        const Text(
                                          'Google Developers SSA Machine Learning BootCamp',
                                          style: TextStyle(
                                              fontWeight: FontWeight.w500,
                                              fontSize: 16,
                                              height: 1.2),
                                          maxLines: 2,
                                        ),
                                        const SizedBox(height: 10),
                                        const Text('Fully Funded',
                                            style: TextStyle(
                                                fontStyle: FontStyle.italic,
                                                fontSize: 13,
                                                color: CustomColors.darkGrey)),
                                        const Text(
                                          'Deadline: 17 July',
                                          style: TextStyle(
                                              height: 1.4,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        GestureDetector(
                                            onTap: () {},
                                            child: const Text(
                                              'Read more',
                                              textAlign: TextAlign.end,
                                              style: TextStyle(
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 13,
                                                  color: CustomColors.shade),
                                            ))
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            )),
                      );
                    }),
              ),
              const SizedBox(height: 4),
              Padding(
                  padding: CustomPadding.all_12,
                  child: GestureDetector(
                    onTap: () {},
                    child: const Text(
                      'View All (25)',
                      textAlign: TextAlign.end,
                    ),
                  )),
            ],
          ),
        ));
  }
}
