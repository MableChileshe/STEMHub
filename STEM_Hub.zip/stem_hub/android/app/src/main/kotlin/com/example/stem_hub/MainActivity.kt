package com.example.stem_hub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
